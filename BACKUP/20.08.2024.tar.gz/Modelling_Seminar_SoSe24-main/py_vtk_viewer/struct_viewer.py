import vtk
import tkinter as tk
from tkinter import filedialog

def load_and_visualize_vtk():
    # Create a Tkinter root window
    root = tk.Tk()
    root.withdraw()  # Hide the root window

    # Open a file dialog to select the .vtk file
    vtk_file_path = filedialog.askopenfilename(
        title="Select a VTK File",
        filetypes=[("VTK files", "*.vtk")]
    )

    # If no file is selected, exit the function
    if not vtk_file_path:
        print("No file selected.")
        return

    # Read the .vtk file
    reader = vtk.vtkStructuredGridReader()
    reader.SetFileName(vtk_file_path)
    reader.Update()

    # Create a mapper for the grid edges (wireframe)
    wireframe_mapper = vtk.vtkDataSetMapper()
    wireframe_mapper.SetInputConnection(reader.GetOutputPort())

    # Create an actor for the grid edges
    wireframe_actor = vtk.vtkActor()
    wireframe_actor.SetMapper(wireframe_mapper)
    wireframe_actor.GetProperty().SetRepresentationToWireframe()  # Wireframe representation
    wireframe_actor.GetProperty().SetOpacity(0.5)  # Translucent
    wireframe_actor.GetProperty().SetColor(1.0, 1.0, 1.0)  # White color

    # Create a mapper for the vertices (points)
    vertices_mapper = vtk.vtkDataSetMapper()
    vertices_mapper.SetInputConnection(reader.GetOutputPort())

    # Create an actor for the vertices
    vertices_actor = vtk.vtkActor()
    vertices_actor.SetMapper(vertices_mapper)
    vertices_actor.GetProperty().SetRepresentationToPoints()  # Points representation
    vertices_actor.GetProperty().SetPointSize(5)  # Point size
    vertices_actor.GetProperty().SetColor(1.0, 0.0, 0.0)  # Red color

    # Create a renderer
    renderer = vtk.vtkRenderer()
    renderer.AddActor(wireframe_actor)  # Add wireframe actor
    renderer.AddActor(vertices_actor)   # Add vertices actor
    renderer.SetBackground(0.1, 0.2, 0.4)  # Set background color

    # Create a render window
    renderWindow = vtk.vtkRenderWindow()
    renderWindow.AddRenderer(renderer)

    # Create an interactor
    renderWindowInteractor = vtk.vtkRenderWindowInteractor()
    renderWindowInteractor.SetRenderWindow(renderWindow)

    # Start the visualization
    renderWindow.Render()
    renderWindowInteractor.Start()

if __name__ == "__main__":
    load_and_visualize_vtk()

