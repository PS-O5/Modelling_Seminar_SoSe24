import vtk

# Function to visualize a VTK mesh file with translucent volume and grid lines
def visualize_vtk_mesh(file_path):
    # Create a reader for the VTK file
    reader = vtk.vtkUnstructuredGridReader()
    reader.SetFileName(file_path)
    reader.Update()

    # Get the output of the reader
    output = reader.GetOutput()

    # Create a mapper for the volume (translucent surface)
    volume_mapper = vtk.vtkDataSetMapper()
    volume_mapper.SetInputData(output)

    # Create an actor for the volume
    volume_actor = vtk.vtkActor()
    volume_actor.SetMapper(volume_mapper)
    volume_actor.GetProperty().SetOpacity(0.3)  # Set the volume to be translucent

    # Create a mapper for the grid lines (wireframe)
    wireframe_mapper = vtk.vtkDataSetMapper()
    wireframe_mapper.SetInputData(output)

    # Create an actor for the wireframe
    wireframe_actor = vtk.vtkActor()
    wireframe_actor.SetMapper(wireframe_mapper)
    wireframe_actor.GetProperty().SetRepresentationToWireframe()  # Show grid lines
    wireframe_actor.GetProperty().SetColor(0, 0, 0)  # Set the color of the grid lines (black)

    # Create a renderer, render window, and interactor
    renderer = vtk.vtkRenderer()
    render_window = vtk.vtkRenderWindow()
    render_window.AddRenderer(renderer)
    render_window_interactor = vtk.vtkRenderWindowInteractor()
    render_window_interactor.SetRenderWindow(render_window)

    # Add the actors to the scene
    renderer.AddActor(volume_actor)
    renderer.AddActor(wireframe_actor)
    renderer.SetBackground(0.1, 0.1, 0.1)  # Set background color

    # Render the scene (lights and cameras are created automatically)
    render_window.Render()

    # Start the interaction
    render_window_interactor.Start()

# Path to your VTK file
file_path = '../temp/build/partitioned_output.vtk'

# Call the function to visualize the mesh with translucent volume and grid lines
visualize_vtk_mesh(file_path)

