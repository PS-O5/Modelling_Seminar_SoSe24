import pyvista as pv
import tkinter as tk
from tkinter import filedialog

# Function to open a file dialog and return the selected file path
def select_vtk_file():
    root = tk.Tk()
    root.withdraw()  # Hide the root window
    file_path = filedialog.askopenfilename(
        title="Select a VTK file",
        filetypes=[("VTK files", "*.vtk"), ("All files", "*.*")]
    )
    return file_path

# Select the VTK file using the file dialog
vtk_file_path = select_vtk_file()

# Check if a file was selected
if not vtk_file_path:
    print("No file selected. Exiting.")
else:
    # Load the selected VTK file
    mesh = pv.read(vtk_file_path)

    # Assuming the partition IDs are stored in a cell array called "PartitionID"
    if "PartitionID" in mesh.cell_data:
        # Extract the partition IDs
        partition_ids = mesh.cell_data["PartitionID"]

        # Plot the mesh with partitioning and translucent faces
        plotter = pv.Plotter()

        # Set scalar visibility based on partition IDs
        plotter.add_mesh(mesh, scalars=partition_ids, cmap="tab20", show_edges=True, opacity=0.5)
        plotter.add_scalar_bar(title="Partition ID")
        
        # Display the plot
        plotter.show()
    else:
        print("The selected VTK file does not contain a 'PartitionID' field.")

