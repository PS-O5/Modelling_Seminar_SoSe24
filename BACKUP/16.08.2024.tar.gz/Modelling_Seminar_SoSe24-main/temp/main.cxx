#include <metis.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include <sstream>

void ConvertMeshToGraph(idx_t nn, idx_t ne, const std::vector<idx_t>& eptr, const std::vector<idx_t>& eind, 
                        std::vector<idx_t>& xadj, std::vector<idx_t>& adjncy)
{
    std::vector<std::set<idx_t>> adjacency_list(nn);

    for (idx_t elem = 0; elem < ne; ++elem)
    {
        idx_t start = eptr[elem];
        idx_t end = eptr[elem + 1];
        for (idx_t i = start; i < end; ++i)
        {
            for (idx_t j = i + 1; j < end; ++j)
            {
                idx_t node1 = eind[i];
                idx_t node2 = eind[j];

                adjacency_list[node1].insert(node2);
                adjacency_list[node2].insert(node1);
            }
        }
    }

    xadj.resize(nn + 1);
    adjncy.clear();

    idx_t edge_count = 0;
    for (idx_t node = 0; node < nn; ++node)
    {
        xadj[node] = edge_count;
        adjncy.insert(adjncy.end(), adjacency_list[node].begin(), adjacency_list[node].end());
        edge_count += adjacency_list[node].size();
    }
    xadj[nn] = edge_count;
}

int main(int argc, char* argv[])
{
    if (argc < 3)
    {
        std::cerr << "Usage: " << argv[0] << " input.txt output.txt" << std::endl;
        return EXIT_FAILURE;
    }

    std::ifstream inputFile(argv[1]);
    if (!inputFile.is_open())
    {
        std::cerr << "Error opening input file: " << argv[1] << std::endl;
        return EXIT_FAILURE;
    }

    std::ofstream outputFile(argv[2]);
    if (!outputFile.is_open())
    {
        std::cerr << "Error opening output file: " << argv[2] << std::endl;
        return EXIT_FAILURE;
    }

    idx_t nn = 0, ne = 0;
    std::vector<idx_t> eptr;
    std::vector<idx_t> eind;

    std::string line;
    while (std::getline(inputFile, line))
    {
        std::istringstream iss(line);
        std::string key;
        iss >> key;

        if (key == "nn:")
        {
            iss >> nn;
        }
        else if (key == "ne:")
        {
            iss >> ne;
        }
        else if (key == "eptr:")
        {
            idx_t value;
            while (iss >> value)
            {
                eptr.push_back(value);
            }
        }
        else if (key == "eind:")
        {
            idx_t value;
            while (iss >> value)
            {
                eind.push_back(value);
            }
        }
    }

    if (eptr.size() != ne + 1)
    {
        std::cerr << "Error: eptr size is incorrect!" << std::endl;
        return EXIT_FAILURE;
    }

    std::vector<idx_t> xadj;
    std::vector<idx_t> adjncy;
    ConvertMeshToGraph(nn, ne, eptr, eind, xadj, adjncy);

    outputFile << "xadj: ";
    for (size_t i = 0; i < xadj.size(); ++i)
    {
        outputFile << xadj[i] << " ";
    }
    outputFile << "\n";

    outputFile << "adjncy: ";
    for (size_t i = 0; i < adjncy.size(); ++i)
    {
        outputFile << adjncy[i] << " ";
    }
    outputFile << "\n";

    inputFile.close();
    outputFile.close();

    std::cout << "Conversion complete. Graph data written to " << argv[2] << std::endl;

    return EXIT_SUCCESS;
}

