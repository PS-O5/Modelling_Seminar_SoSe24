## vtkToPartition.cpp

Once you have the executable, run it with following argument <br>
```
./executableName location/to/.vtk numPartitions
```
<br>
