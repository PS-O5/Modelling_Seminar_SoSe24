#include "vtkMetisMeshPartitioner.h"

// VTK includes
#include "vtkAlgorithm.h"
#include "vtkCellData.h"
#include "vtkDataObject.h"
#include "vtkIdList.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkNew.h"
#include "vtkObjectFactory.h"
#include "vtkPolyData.h"
#include "vtkStructuredGrid.h"
#include "vtkUnstructuredGrid.h"
#include "vtkXMLUnstructuredGridWriter.h"
#include "vtkDataSetReader.h"
#include "vtkUnstructuredGrid.h"
#include "vtkUnstructuredGridWriter.h"

// C/C++ includes
#include <cassert>
#include <vector>
#include <fstream>
#include <iostream>

#include "metis.h"

namespace { // private namespace

template<typename T>
void PartitionAndWriteGraph(T* data, const std::string& graphFileName, idx_t nparts)
{
    // STEP 1: Setup METIS data-structures
    idx_t ne = data->GetNumberOfCells();
    idx_t nn = data->GetNumberOfPoints();

    // METIS mesh data-structure (see METIS manual Section 5.6)
    std::vector<idx_t> eptr(ne + 1);
    std::vector<idx_t> eind;

    // STEP 2: Convert unstructured grid to METIS mesh
    eptr[0] = 0;
    vtkIdList* cellIds = vtkIdList::New();
    for (vtkIdType cellIdx = 0; cellIdx < data->GetNumberOfCells(); ++cellIdx)
    {
        cellIds->Reset();
        data->GetCellPoints(cellIdx, cellIds);

        for (vtkIdType nodeIdx = 0; nodeIdx < cellIds->GetNumberOfIds(); ++nodeIdx)
        {
            eind.push_back(cellIds->GetId(nodeIdx));
        }

        eptr[cellIdx + 1] = eind.size();
    }
    cellIds->Delete();

    // STEP 3: Write METIS graph data to a file
    std::ofstream graphFile(graphFileName);
    if (!graphFile.is_open())
    {
        std::cerr << "Error opening file: " << graphFileName << std::endl;
        return;
    }

    // Write eptr and eind arrays to the file
    graphFile << "ne: " << ne << "\n";
    graphFile << "nn: " << nn << "\n";
    graphFile << "eptr: ";
    for (size_t i = 0; i < eptr.size(); ++i)
    {
        graphFile << eptr[i] << " ";
    }
    graphFile << "\n";

    graphFile << "eind: ";
    for (size_t i = 0; i < eind.size(); ++i)
    {
        graphFile << eind[i] << " ";
    }
    graphFile << "\n";

    graphFile.close();

    std::cout << "Graph data written to " << graphFileName << std::endl;

    // Now let's partition the mesh using METIS
    std::vector<idx_t> epart(ne);  // Element partition vector
    std::vector<idx_t> npart(nn);  // Node partition vector
    idx_t objval;

    int rc = METIS_PartMeshNodal(&ne, &nn, eptr.data(), eind.data(), nullptr, nullptr, &nparts, nullptr, nullptr, &objval, epart.data(), npart.data());

    if (rc != METIS_OK)
    {
        std::cerr << "METIS partitioning failed with error code: " << rc << std::endl;
        return;
    }

    std::cout << "Mesh partitioned successfully." << std::endl;

    // Add partition ID data to the VTK object
    vtkNew<vtkIntArray> partitionIds;
    partitionIds->SetName("PartitionID");
    partitionIds->SetNumberOfValues(ne);
    for (vtkIdType cellIdx = 0; cellIdx < ne; ++cellIdx)
    {
        partitionIds->SetValue(cellIdx, epart[cellIdx]);
    }
    data->GetCellData()->AddArray(partitionIds);

    std::cout << "Partition IDs added to the VTK object." << std::endl;
}

template<typename T>
void WritePartitionedVTK(T* data, const std::string& outputFileName)
{
    vtkNew<vtkUnstructuredGridWriter> writer;
    writer->SetFileName(outputFileName.c_str());
    writer->SetInputData(data);
    writer->Write();
    std::cout << "Partitioned VTK file written to " << outputFileName << std::endl;
}

} // end of private namespace

//------------------------------------------------------------------------------
vtkStandardNewMacro(vtkMetisMeshPartitioner);

//------------------------------------------------------------------------------
vtkMetisMeshPartitioner::vtkMetisMeshPartitioner()
{
    this->NumberOfPartitions = 5;
}

//------------------------------------------------------------------------------
vtkMetisMeshPartitioner::~vtkMetisMeshPartitioner()
{
}

//------------------------------------------------------------------------------
void vtkMetisMeshPartitioner::PrintSelf(ostream& os, vtkIndent indent)
{
    this->Superclass::PrintSelf(os, indent);
}

//------------------------------------------------------------------------------
int vtkMetisMeshPartitioner::RequestData(
    vtkInformation* vtkNotUsed(request),
    vtkInformationVector** inputVector,
    vtkInformationVector* outputVector)
{
    // STEP 0: Get input object
    vtkInformation* input = inputVector[0]->GetInformationObject(0);
    assert("pre: input information object is NULL!" && (input != NULL));
    vtkDataObject* inputData = input->Get(vtkDataObject::DATA_OBJECT());
    assert("pre: input grid is NULL!" && (inputData != NULL));

    // STEP 1: Get output object
    vtkInformation* output = outputVector->GetInformationObject(0);
    assert("pre: output information object is NULL!" && (output != NULL));
    vtkDataObject* outputData = output->Get(vtkDataObject::DATA_OBJECT());

    // STEP 2: Shallow copy input object to output
    outputData->ShallowCopy(inputData);

    // STEP 3: Short-circuit here if we are not partitioning
    if (this->NumberOfPartitions < 2)
    {
        return 1;
    }

    if (vtkUnstructuredGrid::SafeDownCast(outputData))
    {
        PartitionAndWriteGraph(vtkUnstructuredGrid::SafeDownCast(outputData), "graph_data.txt", this->NumberOfPartitions);
        WritePartitionedVTK(vtkUnstructuredGrid::SafeDownCast(outputData), "partitioned_output.vtk");
    }
    else if (vtkPolyData::SafeDownCast(outputData))
    {
        PartitionAndWriteGraph(vtkPolyData::SafeDownCast(outputData), "graph_data.txt", this->NumberOfPartitions);
        WritePartitionedVTK(vtkPolyData::SafeDownCast(outputData), "partitioned_output.vtk");
    }
    else if (vtkStructuredGrid::SafeDownCast(outputData))
    {
        PartitionAndWriteGraph(vtkStructuredGrid::SafeDownCast(outputData), "graph_data.txt", this->NumberOfPartitions);
        WritePartitionedVTK(vtkStructuredGrid::SafeDownCast(outputData), "partitioned_output.vtk");
    }
    else
    {
        vtkErrorMacro(<<"Unsupported data type");
        return 0;
    }
    return 1;
}

// Main function with argc and argv to handle file names
int main(int argc, char* argv[])
{
    if (argc < 4)
    {
        std::cerr << "Usage: " << argv[0] << " input.vtk graph_output.txt partitioned_output.vtk" << std::endl;
        return EXIT_FAILURE;
    }

    // Use vtkDataSetReader for legacy .vtk files
    vtkNew<vtkDataSetReader> reader;
    reader->SetFileName(argv[1]);
    reader->Update();

    vtkUnstructuredGrid* grid = vtkUnstructuredGrid::SafeDownCast(reader->GetOutput());

    if (!grid)
    {
        std::cerr << "Error: Could not read unstructured grid from " << argv[1] << std::endl;
        return EXIT_FAILURE;
    }

    // Create the partitioner
    vtkNew<vtkMetisMeshPartitioner> partitioner;
    partitioner->SetInputData(grid);

    // Write graph data to the specified file
    PartitionAndWriteGraph(grid, argv[2], partitioner->GetNumberOfPartitions());

    // Write the partitioned VTK file
    WritePartitionedVTK(grid, argv[3]);

    return EXIT_SUCCESS;
}

