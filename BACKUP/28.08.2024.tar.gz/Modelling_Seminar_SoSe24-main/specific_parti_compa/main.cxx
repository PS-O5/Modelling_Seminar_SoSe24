#include <vtkSmartPointer.h>
#include <vtkUnstructuredGrid.h>
#include <vtkUnstructuredGridReader.h>
#include <vtkCellData.h>
#include <vtkPointData.h>
#include <vtkDataSet.h>
#include <vtkIntArray.h>
#include <vtkCell.h>
#include <vtkPoints.h>
#include <vtkIdList.h>
#include <vtkFieldData.h>

#include <iostream>
#include <map>
#include <set>
#include <string>
#include <vector>
#include <numeric>
#include <limits>

// Function to parse and analyze communication for a specific partition
std::set<int> analyzePartitionCommunication(vtkUnstructuredGrid* unstructuredGrid, int targetPartitionId) {
    vtkCellData* cellData = unstructuredGrid->GetCellData();
    std::set<int> communicationSet;

    if (!cellData) {
        std::cerr << "No cell data found in the VTK file." << std::endl;
        return communicationSet;
    }

    vtkIntArray* partitionArray = vtkIntArray::SafeDownCast(cellData->GetArray("PartitionID"));
    
    if (!partitionArray) {
        std::cerr << "No PartitionID data found in the VTK file." << std::endl;
        return communicationSet;
    }

    for (vtkIdType i = 0; i < unstructuredGrid->GetNumberOfCells(); ++i) {
        vtkCell* cell = unstructuredGrid->GetCell(i);
        int partitionId = partitionArray->GetValue(i);

        if (partitionId != targetPartitionId) {
            continue;
        }

        vtkIdList* pointIds = cell->GetPointIds();
        for (vtkIdType j = 0; j < pointIds->GetNumberOfIds(); ++j) {
            vtkIdType pointId = pointIds->GetId(j);

            vtkSmartPointer<vtkIdList> neighboringCells = vtkSmartPointer<vtkIdList>::New();
            unstructuredGrid->GetPointCells(pointId, neighboringCells);

            for (vtkIdType k = 0; k < neighboringCells->GetNumberOfIds(); ++k) {
                vtkIdType neighborCellId = neighboringCells->GetId(k);
                int neighborPartitionId = partitionArray->GetValue(neighborCellId);

                if (neighborPartitionId != targetPartitionId) {
                    communicationSet.insert(neighborPartitionId);
                }
            }
        }
    }

    return communicationSet;
}

// Function to compare communication results between multiple VTK files for a specific partition
void compareCommunicationResults(const std::vector<std::string>& vtkFiles, int targetPartitionId) {
    int bestFileIndex = -1;
    int minCommunications = std::numeric_limits<int>::max();

    for (size_t i = 0; i < vtkFiles.size(); ++i) {
        std::cout << "Analyzing file: " << vtkFiles[i] << std::endl;

        vtkSmartPointer<vtkUnstructuredGridReader> reader = vtkSmartPointer<vtkUnstructuredGridReader>::New();
        reader->SetFileName(vtkFiles[i].c_str());
        reader->Update();

        vtkUnstructuredGrid* unstructuredGrid = reader->GetOutput();
        if (!unstructuredGrid) {
            std::cerr << "Failed to read the VTK file: " << vtkFiles[i] << std::endl;
            continue;
        }

        std::set<int> communicationSet = analyzePartitionCommunication(unstructuredGrid, targetPartitionId);

        int communicationCount = communicationSet.size();
        std::cout << "Partition " << targetPartitionId << " communicates with " << communicationCount << " other partitions in file: " << vtkFiles[i] << std::endl;

        if (communicationCount < minCommunications) {
            minCommunications = communicationCount;
            bestFileIndex = static_cast<int>(i);
        }

        std::cout << std::endl;
    }

    if (bestFileIndex >= 0) {
        std::cout << "The file with the least communication for partition " << targetPartitionId << " is: " << vtkFiles[bestFileIndex] << std::endl;
    } else {
        std::cout << "No valid VTK files were processed." << std::endl;
    }
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        std::cerr << "Usage: " << argv[0] << " <target_partition_id> <path_to_vtk_file_1> [<path_to_vtk_file_2> ...]" << std::endl;
        return EXIT_FAILURE;
    }

    int targetPartitionId = std::stoi(argv[1]);

    std::vector<std::string> vtkFiles;
    for (int i = 2; i < argc; ++i) {
        vtkFiles.push_back(argv[i]);
    }

    compareCommunicationResults(vtkFiles, targetPartitionId);

    return EXIT_SUCCESS;
}

