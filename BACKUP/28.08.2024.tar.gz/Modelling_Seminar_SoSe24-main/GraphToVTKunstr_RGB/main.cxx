#include <vtkSmartPointer.h>
#include <vtkUnstructuredGrid.h>
#include <vtkUnstructuredGridReader.h>
#include <vtkUnstructuredGridWriter.h>
#include <vtkCellArray.h>
#include <vtkIdList.h>
#include <vtkUnsignedCharArray.h>
#include <vtkPoints.h>
#include <vtkPointData.h>

#include <fstream>
#include <iostream>
#include <vector>
#include <unordered_map>

std::vector<int> readPartitionFile(const std::string& filename) {
    std::ifstream inFile(filename);
    if (!inFile.is_open()) {
        std::cerr << "Failed to open partition file: " << filename << std::endl;
        exit(EXIT_FAILURE);
    }

    std::vector<int> partitions;
    int part;
    while (inFile >> part) {
        partitions.push_back(part);
    }
    inFile.close();

    return partitions;
}

vtkSmartPointer<vtkUnsignedCharArray> generateColors(const std::vector<int>& partitions) {
    vtkSmartPointer<vtkUnsignedCharArray> colors = vtkSmartPointer<vtkUnsignedCharArray>::New();
    colors->SetNumberOfComponents(3);
    colors->SetName("Colors");

    std::unordered_map<int, std::array<unsigned char, 3>> colorMap;

    for (size_t i = 0; i < partitions.size(); ++i) {
        int partition = partitions[i];
        if (colorMap.find(partition) == colorMap.end()) {
            colorMap[partition] = { static_cast<unsigned char>(rand() % 256),
                                    static_cast<unsigned char>(rand() % 256),
                                    static_cast<unsigned char>(rand() % 256) };
        }
        colors->InsertNextTuple3(colorMap[partition][0], colorMap[partition][1], colorMap[partition][2]);
    }

    return colors;
}

int main(int argc, char* argv[]) {
    if (argc != 4) {
        std::cerr << "Usage: " << argv[0] << " input.vtk partition_file output.vtk" << std::endl;
        return EXIT_FAILURE;
    }

    std::string inputFilename = argv[1];
    std::string partitionFilename = argv[2];
    std::string outputFilename = argv[3];

    // Read the original VTK file (Unstructured Grid)
    vtkSmartPointer<vtkUnstructuredGridReader> reader = vtkSmartPointer<vtkUnstructuredGridReader>::New();
    reader->SetFileName(inputFilename.c_str());
    reader->Update();

    vtkSmartPointer<vtkUnstructuredGrid> unstructuredGrid = reader->GetOutput();

    // Read the partition file
    std::vector<int> partitions = readPartitionFile(partitionFilename);
    if (partitions.size() != static_cast<size_t>(unstructuredGrid->GetNumberOfPoints())) {
        std::cerr << "Number of partitions does not match the number of vertices in the mesh." << std::endl;
        return EXIT_FAILURE;
    }

    // Generate colors based on partitions
    vtkSmartPointer<vtkUnsignedCharArray> colors = generateColors(partitions);

    // Assign colors to the vertices
    unstructuredGrid->GetPointData()->SetScalars(colors);

    // Set the color array as the active scalars for rendering
    unstructuredGrid->GetPointData()->SetActiveScalars("Colors");

    // Write the new VTK file with colors
    vtkSmartPointer<vtkUnstructuredGridWriter> writer = vtkSmartPointer<vtkUnstructuredGridWriter>::New();
    writer->SetFileName(outputFilename.c_str());
    writer->SetInputData(unstructuredGrid);
    writer->Write();

    std::cout << "Partitioned VTK file saved to " << outputFilename << std::endl;

    return EXIT_SUCCESS;
}

