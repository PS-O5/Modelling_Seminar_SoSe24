import vtk

# Create a reader for the VTK unstructured grid file
filename = "../PP_Rand_Domain/modified_cube6.vtk"
reader = vtk.vtkUnstructuredGridReader()
reader.SetFileName(filename)
reader.Update()

# Get the output data (unstructured grid)
unstructured_grid = reader.GetOutput()

# Create a mapper and actor for the unstructured grid
mapper = vtk.vtkDataSetMapper()
mapper.SetInputData(unstructured_grid)

actor = vtk.vtkActor()
actor.SetMapper(mapper)

# Set the actor to render the mesh as a wireframe
actor.GetProperty().SetRepresentationToWireframe()
actor.GetProperty().SetColor(0.0, 0.0, 0.0)  # Set the color of the wireframe to black

# Set the opacity to make the wireframe less intense
actor.GetProperty().SetOpacity(0.7)

# Create a renderer, render window, and interactor
renderer = vtk.vtkRenderer()
render_window = vtk.vtkRenderWindow()
render_window.AddRenderer(renderer)
render_window_interactor = vtk.vtkRenderWindowInteractor()
render_window_interactor.SetRenderWindow(render_window)

# Add the actor to the scene
renderer.AddActor(actor)
renderer.SetBackground(1, 1, 1)  # Set background to white

# Create labels for the cells
label_mapper = vtk.vtkLabeledDataMapper()
label_mapper.SetInputData(unstructured_grid)
label_mapper.SetLabelModeToLabelIds()

label_actor = vtk.vtkActor2D()
label_actor.SetMapper(label_mapper)

# Set label properties to make them less straining
text_property = vtk.vtkTextProperty()
text_property.SetColor(0.0, 0.0, 0.0)  # Black text color
text_property.SetFontSize(12)  # Set the font size to a smaller value
label_mapper.SetLabelTextProperty(text_property)

renderer.AddActor(label_actor)

# Render and interact
render_window.Render()
render_window_interactor.Start()

