#include <vtkSmartPointer.h>
#include <vtkUnstructuredGrid.h>
#include <vtkUnstructuredGridReader.h>
#include <vtkRenderWindow.h>
#include <vtkRenderer.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkDataSetMapper.h>
#include <vtkActor.h>
#include <vtkProperty.h>
#include <vtkTextProperty.h>
#include <vtkCellCenters.h>
#include <vtkPolyDataMapper.h>
#include <vtkLabeledDataMapper.h>
#include <vtkStringArray.h>
#include <vtkPointData.h>
#include <vtkCellData.h>
#include <vtkActor2D.h>
#include <vtkNamedColors.h>
#include <vtkAxesActor.h>
#include <vtkOrientationMarkerWidget.h>

// Function to create a file dialog and return the selected file path
std::string GetFileLocation()
{
    char filename[1024];
    FILE *fp = popen("zenity --file-selection --file-filter='*.vtk'", "r");
    fgets(filename, 1024, fp);
    pclose(fp);
    filename[strlen(filename) - 1] = '\0'; // remove newline character
    return std::string(filename);
}

int main(int argc, char *argv[])
{
    // Get the VTK file location
    std::string filename = GetFileLocation();

    if (filename.empty())
    {
        std::cerr << "No file selected. Exiting..." << std::endl;
        return EXIT_FAILURE;
    }

    // Create a reader to load the legacy VTK file
    vtkSmartPointer<vtkUnstructuredGridReader> reader = vtkSmartPointer<vtkUnstructuredGridReader>::New();
    reader->SetFileName(filename.c_str());
    reader->Update();

    // Get the unstructured grid
    vtkSmartPointer<vtkUnstructuredGrid> mesh = reader->GetOutput();

    // Create a mapper and actor for the mesh
    vtkSmartPointer<vtkDataSetMapper> mapper = vtkSmartPointer<vtkDataSetMapper>::New();
    mapper->SetInputData(mesh);

    vtkSmartPointer<vtkActor> actor = vtkSmartPointer<vtkActor>::New();
    actor->SetMapper(mapper);
    actor->GetProperty()->SetOpacity(0.5); // Set opacity to 50%
    actor->GetProperty()->EdgeVisibilityOn(); // Show edges

    // Create a renderer and render window
    vtkSmartPointer<vtkRenderer> renderer = vtkSmartPointer<vtkRenderer>::New();
    vtkSmartPointer<vtkRenderWindow> renderWindow = vtkSmartPointer<vtkRenderWindow>::New();
    renderWindow->AddRenderer(renderer);

    // Create a render window interactor
    vtkSmartPointer<vtkRenderWindowInteractor> renderWindowInteractor = vtkSmartPointer<vtkRenderWindowInteractor>::New();
    renderWindowInteractor->SetRenderWindow(renderWindow);

    // Add the actor to the scene
    renderer->AddActor(actor);

    // Calculate cell centers
    vtkSmartPointer<vtkCellCenters> cellCenters = vtkSmartPointer<vtkCellCenters>::New();
    cellCenters->SetInputData(mesh);
    cellCenters->Update();

    vtkSmartPointer<vtkPolyData> centers = cellCenters->GetOutput();

    // Create labels for each cell
    vtkSmartPointer<vtkStringArray> labels = vtkSmartPointer<vtkStringArray>::New();
    labels->SetName("Cell IDs");

    for (vtkIdType i = 0; i < mesh->GetNumberOfCells(); ++i)
    {
        labels->InsertNextValue(std::to_string(i));
    }

    centers->GetPointData()->AddArray(labels);

    // Create a label mapper
    vtkSmartPointer<vtkLabeledDataMapper> labelMapper = vtkSmartPointer<vtkLabeledDataMapper>::New();
    labelMapper->SetInputData(centers);
    labelMapper->SetLabelModeToLabelFieldData();
    labelMapper->SetFieldDataName("Cell IDs");

    vtkSmartPointer<vtkTextProperty> textProperty = vtkSmartPointer<vtkTextProperty>::New();
    textProperty->SetFontSize(12);
    textProperty->SetColor(1.0, 0.0, 0.0);
    labelMapper->SetLabelTextProperty(textProperty);

    vtkSmartPointer<vtkActor2D> labelActor = vtkSmartPointer<vtkActor2D>::New();
    labelActor->SetMapper(labelMapper);

    renderer->AddActor(labelActor);

    // Set the background color
    vtkSmartPointer<vtkNamedColors> colors = vtkSmartPointer<vtkNamedColors>::New();
    renderer->SetBackground(colors->GetColor3d("MidnightBlue").GetData());

    // Add the axes actor to show orientation
    vtkSmartPointer<vtkAxesActor> axes = vtkSmartPointer<vtkAxesActor>::New();
    vtkSmartPointer<vtkOrientationMarkerWidget> widget = vtkSmartPointer<vtkOrientationMarkerWidget>::New();
    widget->SetOrientationMarker(axes);
    widget->SetInteractor(renderWindowInteractor);
    widget->SetViewport(0.0, 0.0, 0.3, 0.3);
    widget->SetEnabled(1);
    widget->InteractiveOn();

    // Render and start interaction
    renderWindow->Render();
    renderWindowInteractor->Start();

    return EXIT_SUCCESS;
}

