#include <gtk/gtk.h>
#include <vtkSmartPointer.h>
#include <vtkUnstructuredGrid.h>
#include <vtkUnstructuredGridReader.h>
#include <vtkCellData.h>
#include <vtkPointData.h>
#include <vtkDataSet.h>
#include <vtkIntArray.h>
#include <vtkCell.h>
#include <vtkPoints.h>
#include <vtkIdList.h>
#include <vtkFieldData.h>

#include <iostream>
#include <map>
#include <set>
#include <string>
#include <vector>
#include <numeric>
#include <limits>

std::set<int> analyzePartitionCommunication(vtkUnstructuredGrid* unstructuredGrid, int targetPartitionId) {
    vtkCellData* cellData = unstructuredGrid->GetCellData();
    std::set<int> communicationSet;

    if (!cellData) {
        std::cerr << "No cell data found in the VTK file." << std::endl;
        return communicationSet;
    }

    vtkIntArray* partitionArray = vtkIntArray::SafeDownCast(cellData->GetArray("PartitionID"));
    
    if (!partitionArray) {
        std::cerr << "No PartitionID data found in the VTK file." << std::endl;
        return communicationSet;
    }

    for (vtkIdType i = 0; i < unstructuredGrid->GetNumberOfCells(); ++i) {
        vtkCell* cell = unstructuredGrid->GetCell(i);
        int partitionId = partitionArray->GetValue(i);

        if (partitionId != targetPartitionId) {
            continue;
        }

        vtkIdList* pointIds = cell->GetPointIds();
        for (vtkIdType j = 0; j < pointIds->GetNumberOfIds(); ++j) {
            vtkIdType pointId = pointIds->GetId(j);

            vtkSmartPointer<vtkIdList> neighboringCells = vtkSmartPointer<vtkIdList>::New();
            unstructuredGrid->GetPointCells(pointId, neighboringCells);

            for (vtkIdType k = 0; k < neighboringCells->GetNumberOfIds(); ++k) {
                vtkIdType neighborCellId = neighboringCells->GetId(k);
                int neighborPartitionId = partitionArray->GetValue(neighborCellId);

                if (neighborPartitionId != targetPartitionId) {
                    communicationSet.insert(neighborPartitionId);
                }
            }
        }
    }

    return communicationSet;
}

void compareCommunicationResults(const std::vector<std::string>& vtkFiles, int targetPartitionId) {
    int bestFileIndex = -1;
    int minCommunications = std::numeric_limits<int>::max();

    for (size_t i = 0; i < vtkFiles.size(); ++i) {
        std::cout << "Analyzing file: " << vtkFiles[i] << std::endl;

        vtkSmartPointer<vtkUnstructuredGridReader> reader = vtkSmartPointer<vtkUnstructuredGridReader>::New();
        reader->SetFileName(vtkFiles[i].c_str());
        reader->Update();

        vtkUnstructuredGrid* unstructuredGrid = reader->GetOutput();
        if (!unstructuredGrid) {
            std::cerr << "Failed to read the VTK file: " << vtkFiles[i] << std::endl;
            continue;
        }

        std::set<int> communicationSet = analyzePartitionCommunication(unstructuredGrid, targetPartitionId);

        int communicationCount = communicationSet.size();
        std::cout << "Partition " << targetPartitionId << " communicates with " << communicationCount << " other partitions in file: " << vtkFiles[i] << std::endl;

        if (communicationCount < minCommunications) {
            minCommunications = communicationCount;
            bestFileIndex = static_cast<int>(i);
        }

        std::cout << std::endl;
    }

    if (bestFileIndex >= 0) {
        std::cout << "The file with the least communication for partition " << targetPartitionId << " is: " << vtkFiles[bestFileIndex] << std::endl;
    } else {
        std::cout << "No valid VTK files were processed." << std::endl;
    }
}

static void on_file_open(GtkWidget *widget, gpointer data) {
    GtkWidget *dialog;
    GtkFileChooser *chooser;
    GtkFileChooserAction action = GTK_FILE_CHOOSER_ACTION_OPEN;
    gint res;

    dialog = gtk_file_chooser_dialog_new("Open File",
                                         GTK_WINDOW(data),
                                         action,
                                         "_Cancel",
                                         GTK_RESPONSE_CANCEL,
                                         "_Open",
                                         GTK_RESPONSE_ACCEPT,
                                         NULL);
    chooser = GTK_FILE_CHOOSER(dialog);
    gtk_file_chooser_set_select_multiple(chooser, TRUE);

    res = gtk_dialog_run(GTK_DIALOG(dialog));
    if (res == GTK_RESPONSE_ACCEPT) {
        GSList *filenames = gtk_file_chooser_get_filenames(chooser);
        std::vector<std::string> vtkFiles;

        for (GSList *iter = filenames; iter != NULL; iter = iter->next) {
            vtkFiles.push_back(static_cast<char *>(iter->data));
            g_free(iter->data); // Free each filename string after use
        }

        g_slist_free(filenames); // Free the GSList structure

        GtkWidget *inputDialog;
        GtkWidget *content_area;
        GtkWidget *entry;
	
	GtkDialogFlags flags = static_cast<GtkDialogFlags>(GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT);

        inputDialog = gtk_dialog_new_with_buttons("Target Partition ID",
                                                  GTK_WINDOW(data),
                                                  flags,
                                                  "_OK",
                                                  GTK_RESPONSE_OK,
                                                  "_Cancel",
                                                  GTK_RESPONSE_CANCEL,
                                                  NULL);

        content_area = gtk_dialog_get_content_area(GTK_DIALOG(inputDialog));
        entry = gtk_entry_new();
        gtk_entry_set_text(GTK_ENTRY(entry), "0");
        gtk_container_add(GTK_CONTAINER(content_area), entry);
        gtk_widget_show_all(inputDialog);

        gint response = gtk_dialog_run(GTK_DIALOG(inputDialog));
        if (response == GTK_RESPONSE_OK) {
            const gchar *partition_id_str = gtk_entry_get_text(GTK_ENTRY(entry));
            int targetPartitionId = std::stoi(partition_id_str);

            compareCommunicationResults(vtkFiles, targetPartitionId);
        }

        gtk_widget_destroy(inputDialog);
    }

    gtk_widget_destroy(dialog);
}

int main(int argc, char *argv[]) {
    gtk_init(&argc, &argv);

    GtkWidget *window;
    GtkWidget *button;
    GtkWidget *box;

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "VTK Partition Analysis");
    gtk_window_set_default_size(GTK_WINDOW(window), 200, 100);
    gtk_container_set_border_width(GTK_CONTAINER(window), 10);

    box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_container_add(GTK_CONTAINER(window), box);

    button = gtk_button_new_with_label("Select VTK Files and Partition ID");
    g_signal_connect(button, "clicked", G_CALLBACK(on_file_open), window);
    gtk_box_pack_start(GTK_BOX(box), button, TRUE, TRUE, 0);

    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    gtk_widget_show_all(window);
    gtk_main();

    return 0;
}

