#include "vtkMetisMeshPartitioner.h"

// VTK includes
#include "vtkAlgorithm.h"
#include "vtkCellData.h"
#include "vtkDataObject.h"
#include "vtkIdList.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkNew.h"
#include "vtkObjectFactory.h"
#include "vtkPolyData.h"
#include "vtkStructuredGrid.h"
#include "vtkUnstructuredGrid.h"
#include "vtkUnstructuredGridReader.h"
#include "vtkUnstructuredGridWriter.h"
#include "vtkSmartPointer.h"

// C/C++ includes
#include <cassert>
#include <vector>
#include <string>

#include "metis.h"

bool ALGO, SCHM, WGHT;

namespace { // private namespace

template<typename T>
void Partition(T* data, idx_t nparts)
{
    idx_t ne = data->GetNumberOfCells();
    idx_t nn = data->GetNumberOfPoints();

    std::vector<idx_t> eptr(ne + 1);
    std::vector<idx_t> eind;

    idx_t* vwgt = nullptr;

    if (WGHT) {
        std::cout << "Weighted" << std::endl;

        				//For Opti_parti3.vtk 
  	vwgt = new idx_t[ne];

	for(int k = 0; k < ne; k++){
    		if(k == 82 || k == 81 || k == 80 || k == 76 || k == 74 || k == 73 || k == 72 ||
       			k == 114 || k == 56 || k == 162 || k == 161 || k == 160 || k == 156 || 
       			k == 154 || k == 153 || k == 152 || k == 50 || k == 135 || 
       			k == 88 || k == 89 || k == 91 || k == 95 || k == 100 || k == 101 || k == 103) {
        	vwgt[k] = 1;
    		} else {
        		vwgt[k] = 10;
    		}
	}

	
	
	
	/*vwgt = new idx_t[ne];
        for (int k = 0; k < ne; k++) {
            // Custom logic for weights (you can adjust this)
            vwgt[k] = (k % 2 == 0) ? 10 : 1; // Example weight logic*/
        
    
    
    	}
    
    
    
    
    else {
        std::cout << "Unweighted" << std::endl;
    }

    idx_t* vsize = nullptr;
    real_t* tpwgts = nullptr;
    idx_t ncommon = 1;
    idx_t objval = 0;

    std::vector<idx_t> epart(ne);
    std::vector<idx_t> npart(nn);

    idx_t options[METIS_NOPTIONS];
    METIS_SetDefaultOptions(options);
    options[METIS_OPTION_NUMBERING] = 0;
    options[METIS_OPTION_PTYPE] = (SCHM) ? METIS_PTYPE_KWAY : METIS_PTYPE_RB;

    if (SCHM) {
        std::cout << "K-Way Partitioning" << std::endl;
    } else {
        std::cout << "R-Bisection Partitioning" << std::endl;
    }

    eptr[0] = 0;
    vtkNew<vtkIdList> cellIds;
    for (vtkIdType cellIdx = 0; cellIdx < data->GetNumberOfCells(); ++cellIdx)
    {
        cellIds->Reset();
        data->GetCellPoints(cellIdx, cellIds);

        for (vtkIdType nodeIdx = 0; nodeIdx < cellIds->GetNumberOfIds(); ++nodeIdx)
        {
            eind.push_back(cellIds->GetId(nodeIdx));
        }

        eptr[cellIdx + 1] = static_cast<idx_t>(eind.size());
    }

    int rc;
    if (ALGO) {
        std::cout << "Nodal Mesh" << std::endl;
        rc = METIS_PartMeshNodal(
            &ne, &nn, eptr.data(), eind.data(),
            vwgt, vsize, &nparts, tpwgts, options,
            &objval, epart.data(), npart.data());
    } else {
        std::cout << "Dual Mesh" << std::endl;
        rc = METIS_PartMeshDual(
            &ne, &nn, eptr.data(), eind.data(),
            vwgt, vsize, &ncommon, &nparts, tpwgts, options,
            &objval, epart.data(), npart.data());
    }

    if (WGHT) {
        delete[] vwgt;
    }

    if (rc != METIS_OK)
    {
        std::cerr << "METIS_PartMesh failed with error code: " << rc << std::endl;
        return;
    }

    vtkNew<vtkIntArray> partitionIds;
    partitionIds->SetName("PartitionID");
    partitionIds->SetNumberOfValues(data->GetNumberOfCells());
    for (vtkIdType cellIdx = 0; cellIdx < data->GetNumberOfCells(); ++cellIdx)
    {
        partitionIds->SetValue(cellIdx, epart[cellIdx]);
    }
    data->GetCellData()->AddArray(partitionIds.GetPointer());
}

} // end of private namespace

vtkStandardNewMacro(vtkMetisMeshPartitioner);

vtkMetisMeshPartitioner::vtkMetisMeshPartitioner()
{
    this->NumberOfPartitions = 2; // Default value
}

vtkMetisMeshPartitioner::~vtkMetisMeshPartitioner()
{
}

void vtkMetisMeshPartitioner::PrintSelf(ostream& os, vtkIndent indent)
{
    this->Superclass::PrintSelf(os, indent);
}

int vtkMetisMeshPartitioner::RequestData(
    vtkInformation* vtkNotUsed(request),
    vtkInformationVector** inputVector,
    vtkInformationVector* outputVector)
{
    vtkInformation* input = inputVector[0]->GetInformationObject(0);
    assert("pre: input information object is NULL!" && (input != nullptr));
    vtkDataObject* inputData = input->Get(vtkDataObject::DATA_OBJECT());
    assert("pre: input grid is NULL!" && (inputData != nullptr));

    vtkInformation* output = outputVector->GetInformationObject(0);
    assert("pre: output information object is NULL!" && (output != nullptr));
    vtkDataObject* outputData = output->Get(vtkDataObject::DATA_OBJECT());

    outputData->ShallowCopy(inputData);

    if (this->NumberOfPartitions < 2)
    {
        return 1;
    }

    if (vtkUnstructuredGrid::SafeDownCast(outputData))
    {
        Partition(vtkUnstructuredGrid::SafeDownCast(outputData), this->NumberOfPartitions);
    }
    else if (vtkPolyData::SafeDownCast(outputData))
    {
        Partition(vtkPolyData::SafeDownCast(outputData), this->NumberOfPartitions);
    }
    else if (vtkStructuredGrid::SafeDownCast(outputData))
    {
        Partition(vtkUnstructuredGrid::SafeDownCast(outputData), this->NumberOfPartitions);
    }
    else
    {
        vtkErrorMacro(<<"Unsupported data type");
        return 0;
    }
    return 1;
}

std::string fileNamer(const int& i)
{
    std::string name;
    switch (i) {
        case 0:
            return name = "Dual_rBi_Unweighted.vtk";
        case 1:
            return name = "Dual_rBi_weighted.vtk";
        case 2:
            return name = "Dual_kway_Unweighted.vtk";
        case 3:
            return name = "Dual_kway_weighted.vtk";
        case 4:
            return name = "Nodal_rBi_Unweighted.vtk";
        case 5:
            return name = "Nodal_rBi_weighted.vtk";
        case 6:
            return name = "Nodal_kway_Unweighted.vtk";
        case 7:
            return name = "Nodal_kway_weighted.vtk";
        default:
            return name = "Invalid_File_Generated.vtk";
    }
}

int main(int argc, char* argv[])
{
    if (argc < 3)
    {
        std::cerr << "Usage: " << argv[0] << " <input filename> <No. Partitions>" << std::endl;
        return EXIT_FAILURE;
    }

    const char* inputFilename = argv[1];
    int numParti = std::strtol(argv[2], nullptr, 10);
    if (numParti <= 0) {
        std::cerr << "Wrong partition number" << std::endl;
        return EXIT_FAILURE;
    }

    for (int i = 0; i < 8; ++i) {
        ALGO = i & 4;
        SCHM = i & 2;
        WGHT = i & 1;

        std::string endingChar = fileNamer(i);
        std::string outputFilename = std::string(inputFilename) + std::to_string(numParti)  + endingChar;

        vtkSmartPointer<vtkUnstructuredGridReader> reader = vtkSmartPointer<vtkUnstructuredGridReader>::New();
        reader->SetFileName(inputFilename);
        reader->Update();

        vtkUnstructuredGrid* inputGrid = reader->GetOutput();
        if (!inputGrid)
        {
            std::cerr << "Failed to read the input file." << std::endl;
            return EXIT_FAILURE;
        }

        vtkSmartPointer<vtkMetisMeshPartitioner> partitioner = vtkSmartPointer<vtkMetisMeshPartitioner>::New();
        partitioner->SetNumberOfPartitions(numParti);

        partitioner->SetInputData(inputGrid);
        partitioner->Update();

        vtkUnstructuredGrid* partitionedGrid = vtkUnstructuredGrid::SafeDownCast(partitioner->GetOutput());

        vtkSmartPointer<vtkUnstructuredGridWriter> writer = vtkSmartPointer<vtkUnstructuredGridWriter>::New();
        writer->SetFileName(outputFilename.c_str());
        writer->SetInputData(partitionedGrid);
        writer->Write();

        std::cout << "Partitioned mesh has been written to " << outputFilename << std::endl;
    }

    return EXIT_SUCCESS;
}

