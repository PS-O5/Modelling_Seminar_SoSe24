import vtk

# Step 1: Load the VTK File
file_path = 'cube6.vtk'  # Update this with your file path

reader = vtk.vtkUnstructuredGridReader()
reader.SetFileName(file_path)
reader.Update()
unstructured_grid = reader.GetOutput()

# Step 2: Create a new grid to store cells that are not in the 2x2x2 slot
new_grid = vtk.vtkUnstructuredGrid()
new_grid.Allocate()

# Step 3: Copy points to the new grid
new_points = vtk.vtkPoints()
new_points.DeepCopy(unstructured_grid.GetPoints())
new_grid.SetPoints(new_points)

# Step 4: Add only the cells that do not fall within the 2x2x2 slot at the center bottom
for cell_id in range(unstructured_grid.GetNumberOfCells()):
    cell = unstructured_grid.GetCell(cell_id)
    points = cell.GetPoints()
    keep_cell = True
    
    for i in range(points.GetNumberOfPoints()):
        x, y, z = points.GetPoint(i)
        if (2 < x < 3 and 2 < y < 3 and 0 <= z < 2):
            keep_cell = False
            break
    
    if keep_cell:
        new_grid.InsertNextCell(unstructured_grid.GetCellType(cell_id), cell.GetPointIds())

# Step 5: Save the Modified VTK File
output_file_path = 'modified_cube6.vtk'  # Update this with your desired output file path

writer = vtk.vtkUnstructuredGridWriter()
writer.SetFileName(output_file_path)
writer.SetInputData(new_grid)
writer.Write()

print(f"Modified VTK file saved to {output_file_path}")

