#include "vtkMetisMeshPartitioner.h"

// VTK includes
#include "vtkAlgorithm.h"
#include "vtkCellData.h"
#include "vtkDataObject.h"
#include "vtkIdList.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkNew.h"
#include "vtkObjectFactory.h"
#include "vtkPolyData.h"
#include "vtkStructuredGrid.h"
#include "vtkUnstructuredGrid.h"
#include "vtkUnstructuredGridReader.h"
#include "vtkUnstructuredGridWriter.h"
#include "vtkSmartPointer.h"

// C/C++ includes
#include <cassert>
#include <vector>

#include "metis.h"

namespace { // private namespace

template<typename T>
void Partition(T* data, idx_t nparts)
{
  // STEP 1: Setup metis data-structures
  idx_t ne = data->GetNumberOfCells();
  idx_t nn = data->GetNumberOfPoints();

  // METIS mesh data-structure (see METIS manual Section 5.6)
  std::vector<idx_t> eptr(ne + 1);
  std::vector<idx_t> eind;

  // vectors used for weighted partitioning
  //idx_t* vwgt = nullptr;
  idx_t* vwgt = new idx_t[ne];
  for(int i = 0; i < ne/3; i++){
  vwgt[i] = 10;
  }
  for(int i = ne/3; i < ne; i++){
  vwgt[i] = 1;
  }
  idx_t* vsize = nullptr;
  real_t* tpwgts = nullptr;
  idx_t ncommon = 1;

  // Return values
  idx_t objval = 0; // stores edgecut or total communication volume upon
                    // successful completion.

  std::vector<idx_t> epart(ne); // the element partition vector
  std::vector<idx_t> npart(nn); // the node partition vector

  // STEP 2: Setup the metis options vector
  idx_t options[METIS_NOPTIONS];
  METIS_SetDefaultOptions(options);
  options[METIS_OPTION_NUMBERING] = 0;
  options[METIS_OPTION_PTYPE] = (nparts > 8) ? METIS_PTYPE_KWAY : METIS_PTYPE_RB;

  // STEP 3: Convert unstructured grid to METIS mesh
  eptr[0] = 0;
  vtkNew<vtkIdList> cellIds;
  for (vtkIdType cellIdx = 0; cellIdx < data->GetNumberOfCells(); ++cellIdx)
  {
    cellIds->Reset();
    data->GetCellPoints(cellIdx, cellIds);

    for (vtkIdType nodeIdx = 0; nodeIdx < cellIds->GetNumberOfIds(); ++nodeIdx)
    {
      eind.push_back(cellIds->GetId(nodeIdx));
    }

    eptr[cellIdx + 1] = static_cast<idx_t>(eind.size());
  }

  // STEP 4: Partition METIS mesh
  //std::cout << "nparts: " << nparts << std::endl;
  int rc = METIS_PartMeshDual(
    &ne, &nn, eptr.data(), eind.data(),
    vwgt, vsize, &ncommon, &nparts, tpwgts, options,
    &objval, epart.data(), npart.data());
  /*for(auto& ele : epart){
  	std::cout << ele << " ";
  }
  std::cout << std::endl;
*/
  delete[] vwgt;

  if (rc != METIS_OK)
  {
    std::cerr << "METIS_PartMeshDual failed with error code: " << rc << std::endl;
    return;
  }

  // STEP 5: Add output array
  vtkNew<vtkIntArray> partitionIds;
  partitionIds->SetName("PartitionID");
  partitionIds->SetNumberOfValues(data->GetNumberOfCells());
  for (vtkIdType cellIdx = 0; cellIdx < data->GetNumberOfCells(); ++cellIdx)
  {
    partitionIds->SetValue(cellIdx, epart[cellIdx]);
  }
  data->GetCellData()->AddArray(partitionIds.GetPointer());
}

} // end of private namespace

//------------------------------------------------------------------------------
vtkStandardNewMacro(vtkMetisMeshPartitioner);

//------------------------------------------------------------------------------
vtkMetisMeshPartitioner::vtkMetisMeshPartitioner()
{
  this->NumberOfPartitions = 2; // Default value
}

//------------------------------------------------------------------------------
vtkMetisMeshPartitioner::~vtkMetisMeshPartitioner()
{
}

//------------------------------------------------------------------------------
void vtkMetisMeshPartitioner::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

//------------------------------------------------------------------------------
int vtkMetisMeshPartitioner::RequestData(
  vtkInformation* vtkNotUsed(request),
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  // STEP 0: Get input object
  vtkInformation* input = inputVector[0]->GetInformationObject(0);
  assert("pre: input information object is NULL!" && (input != nullptr));
  vtkDataObject* inputData = input->Get(vtkDataObject::DATA_OBJECT());
  assert("pre: input grid is NULL!" && (inputData != nullptr));

  // STEP 1: Get output object
  vtkInformation* output = outputVector->GetInformationObject(0);
  assert("pre: output information object is NULL!" && (output != nullptr));
  vtkDataObject* outputData = output->Get(vtkDataObject::DATA_OBJECT());

  // STEP 2: Shallow copy input object to output
  outputData->ShallowCopy(inputData);

  // STEP 3: Short-circuit here if we are not partitioning
  if (this->NumberOfPartitions < 2)
  {
    return 1;
  }

  if (vtkUnstructuredGrid::SafeDownCast(outputData))
  {
    Partition(vtkUnstructuredGrid::SafeDownCast(outputData), this->NumberOfPartitions);
  }
  else if (vtkPolyData::SafeDownCast(outputData))
  {
    Partition(vtkPolyData::SafeDownCast(outputData), this->NumberOfPartitions);
  }
  else if (vtkStructuredGrid::SafeDownCast(outputData))
  {
    Partition(vtkUnstructuredGrid::SafeDownCast(outputData), this->NumberOfPartitions);
  }
  else
  {
    vtkErrorMacro(<<"Unsupported data type");
    return 0;
  }
  return 1;
}


int main(int argc, char* argv[])
{
    // STEP 1: Check if filename is provided
    if (argc < 2)
    {
        std::cerr << "Usage: " << argv[0] << " <input filename> [<output filename>]" << std::endl;
        return EXIT_FAILURE;
    }

    const char* inputFilename = argv[1];
    const char* outputFilename = (argc > 2) ? argv[2] : "partitioned_output.vtk";

    // STEP 2: Read the input file (legacy VTK unstructured grid)
    vtkSmartPointer<vtkUnstructuredGridReader> reader = vtkSmartPointer<vtkUnstructuredGridReader>::New();
    reader->SetFileName(inputFilename);
    reader->Update();

    vtkUnstructuredGrid* inputGrid = reader->GetOutput();
    if (!inputGrid)
    {
        std::cerr << "Failed to read the input file." << std::endl;
        return EXIT_FAILURE;
    }

    // STEP 3: Create the partitioner and set the number of partitions
    vtkSmartPointer<vtkMetisMeshPartitioner> partitioner = vtkSmartPointer<vtkMetisMeshPartitioner>::New();
    partitioner->SetNumberOfPartitions(4);  // Or any other number you want to set

    // STEP 4: Set the input and run the partitioner
    partitioner->SetInputData(inputGrid);
    partitioner->Update();

    // STEP 5: Get the partitioned output
    vtkUnstructuredGrid* partitionedGrid = vtkUnstructuredGrid::SafeDownCast(partitioner->GetOutput());

    // STEP 6: Write the partitioned output to a file (legacy VTK unstructured grid)
    vtkSmartPointer<vtkUnstructuredGridWriter> writer = vtkSmartPointer<vtkUnstructuredGridWriter>::New();
    writer->SetFileName(outputFilename);
    writer->SetInputData(partitionedGrid);
    writer->Write();

    std::cout << "Partitioned mesh has been written to " << outputFilename << std::endl;

    return EXIT_SUCCESS;
}

