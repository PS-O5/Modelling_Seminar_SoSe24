import networkx as nx
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np

def read_graph(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()

    # Read number of nodes and edges
    num_nodes, num_edges = map(int, lines[0].strip().split())

    # Create an empty graph
    G = nx.Graph()

    # Add nodes and edges to the graph
    for i in range(1, num_nodes + 1):
        edges = list(map(int, lines[i].strip().split()))
        for edge in edges:
            G.add_edge(i, edge)

    return G

def generate_3d_positions(num_nodes):
    # Generate positions in a 3D grid-like structure
    grid_size = int(np.ceil(num_nodes ** (1/3)))
    pos = {}
    idx = 0
    for x in range(grid_size):
        for y in range(grid_size):
            for z in range(grid_size):
                if idx < num_nodes:
                    pos[idx + 1] = (x, y, z)
                    idx += 1
    return pos

def visualize_graph_3d(G):
    num_nodes = G.number_of_nodes()
    
    # Generate 3D positions for all nodes
    pos = generate_3d_positions(num_nodes)

    # Extract node positions
    nodes = pos.keys()
    node_xyz = [pos[node] for node in nodes]

    # Create a 3D plot
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    # Draw edges
    for edge in G.edges():
        x = [pos[edge[0]][0], pos[edge[1]][0]]
        y = [pos[edge[0]][1], pos[edge[1]][1]]
        z = [pos[edge[0]][2], pos[edge[1]][2]]
        ax.plot(x, y, z, color='black')

    # Draw nodes
    xs, ys, zs = zip(*node_xyz)
    ax.scatter(xs, ys, zs, s=100, color='red')

    # Draw node labels
    for node, (x, y, z) in pos.items():
        ax.text(x, y, z, str(node), size=10, zorder=1, color='black')

    # Set the labels for the axes
    ax.set_xlabel('X axis')
    ax.set_ylabel('Y axis')
    ax.set_zlabel('Z axis')

    plt.title("3D Grid Representation of the Graph")
    plt.show()

# Path to your graph file
graph_file_path = 'cube2.graph'

# Read and visualize the graph as a 3D grid
G = read_graph(graph_file_path)
visualize_graph_3d(G)

