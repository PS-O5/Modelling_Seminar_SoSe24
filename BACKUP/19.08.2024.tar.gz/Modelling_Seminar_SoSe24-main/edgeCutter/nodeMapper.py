import networkx as nx
import matplotlib.pyplot as plt

def read_graph(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()

    # Read number of nodes and edges
    num_nodes, num_edges = map(int, lines[0].strip().split())

    # Create an empty graph
    G = nx.Graph()

    # Add nodes and edges to the graph
    for i in range(1, num_nodes + 1):
        edges = list(map(int, lines[i].strip().split()))
        for edge in edges:
            G.add_edge(i, edge)

    return G

def visualize_graph(G):
    pos = nx.spring_layout(G)  # Position the nodes with a spring layout

    plt.figure(figsize=(10, 10))
    nx.draw(G, pos, with_labels=True, node_color='lightblue', edge_color='gray', node_size=500, font_size=12, font_weight='bold')
    plt.title("Graph Visualization with Node Labels")
    plt.show()

# Path to your graph file
graph_file_path = 'cube2.graph'

# Read and visualize the graph
G = read_graph(graph_file_path)
visualize_graph(G)

