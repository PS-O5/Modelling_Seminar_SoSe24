#include <vtkSmartPointer.h>
#include <vtkUnstructuredGrid.h>
#include <vtkUnstructuredGridReader.h>
#include <vtkCellData.h>
#include <vtkPointData.h>
#include <vtkDataSet.h>
#include <vtkIntArray.h>
#include <vtkCell.h>
#include <vtkPoints.h>
#include <vtkIdList.h>
#include <vtkFieldData.h>

#include <iostream>
#include <map>
#include <set>
#include <string>
#include <vector>
#include <numeric>

// Function to parse and analyze communication between partitions
std::map<int, std::set<int>> analyzePartitionCommunication(vtkUnstructuredGrid* unstructuredGrid) {
    vtkCellData* cellData = unstructuredGrid->GetCellData();
    
    std::map<int, std::set<int>> communicationMap;

    if (!cellData) {
        std::cerr << "No cell data found in the VTK file." << std::endl;
        return communicationMap;
    }

    // Assuming partition information is stored as an integer array in cell data
    vtkIntArray* partitionArray = vtkIntArray::SafeDownCast(cellData->GetArray("PartitionID"));
    
    if (!partitionArray) {
        std::cerr << "No PartitionID data found in the VTK file." << std::endl;
        return communicationMap;
    }

    // Iterate through all the cells in the unstructured grid
    for (vtkIdType i = 0; i < unstructuredGrid->GetNumberOfCells(); ++i) {
        vtkCell* cell = unstructuredGrid->GetCell(i);
        int partitionId = partitionArray->GetValue(i);

        // Iterate through the cell's points to find neighboring cells
        vtkIdList* pointIds = cell->GetPointIds();
        for (vtkIdType j = 0; j < pointIds->GetNumberOfIds(); ++j) {
            vtkIdType pointId = pointIds->GetId(j);

            vtkSmartPointer<vtkIdList> neighboringCells = vtkSmartPointer<vtkIdList>::New();
            unstructuredGrid->GetPointCells(pointId, neighboringCells);

            for (vtkIdType k = 0; k < neighboringCells->GetNumberOfIds(); ++k) {
                vtkIdType neighborCellId = neighboringCells->GetId(k);
                int neighborPartitionId = partitionArray->GetValue(neighborCellId);

                // If the neighboring cell belongs to a different partition, record communication
                if (neighborPartitionId != partitionId) {
                    communicationMap[partitionId].insert(neighborPartitionId);
                }
            }
        }
    }

    // Print the communication analysis results
    std::cout << "Partition Communication Analysis:" << std::endl;
    for (const auto& entry : communicationMap) {
        std::cout << "Partition " << entry.first << " communicates with partitions: ";
        for (int neighborPartition : entry.second) {
            std::cout << neighborPartition << " ";
        }
        std::cout << std::endl;
    }


    return communicationMap;
}

// Function to analyze and print communication metrics
void printCommunicationMetrics(const std::map<int, std::set<int>>& communicationMap) {
    int totalCommunications = 0;
    int maxCommunicationLoad = 0;
    int numPartitions = communicationMap.size();

    for (const auto& entry : communicationMap) {
        int commCount = entry.second.size();
        totalCommunications += commCount;
        if (commCount > maxCommunicationLoad) {
            maxCommunicationLoad = commCount;
        }
    }

    double avgCommunication = static_cast<double>(totalCommunications) / numPartitions;

    std::cout << "Total communications: " << totalCommunications << std::endl;
    std::cout << "Average communications per partition: " << avgCommunication << std::endl;
    std::cout << "Maximum communication load (max number of communications a partition has): " << maxCommunicationLoad << std::endl;
}

// Function to compare communication results between multiple VTK files
void compareCommunicationResults(const std::vector<std::string>& vtkFiles) {
    int bestFileIndex = -1;
    int minTotalCommunications = std::numeric_limits<int>::max();
    double minAvgCommunication = std::numeric_limits<double>::max();
    int minMaxCommunicationLoad = std::numeric_limits<int>::max();

    for (size_t i = 0; i < vtkFiles.size(); ++i) {
        std::cout << "Analyzing file: " << vtkFiles[i] << std::endl;

        // Read the .vtk file
        vtkSmartPointer<vtkUnstructuredGridReader> reader = vtkSmartPointer<vtkUnstructuredGridReader>::New();
        reader->SetFileName(vtkFiles[i].c_str());
        reader->Update();

        vtkUnstructuredGrid* unstructuredGrid = reader->GetOutput();
        if (!unstructuredGrid) {
            std::cerr << "Failed to read the VTK file: " << vtkFiles[i] << std::endl;
            continue;
        }

        // Analyze partition communication
        std::map<int, std::set<int>> communicationMap = analyzePartitionCommunication(unstructuredGrid);

        // Print communication metrics
        std::cout << "Partition Communication Analysis for file: " << vtkFiles[i] << std::endl;
        printCommunicationMetrics(communicationMap);

        // Calculate metrics for comparison
        int totalCommunications = 0;
        int maxCommunicationLoad = 0;
        int numPartitions = communicationMap.size();

        for (const auto& entry : communicationMap) {
            int commCount = entry.second.size();
            totalCommunications += commCount;
            if (commCount > maxCommunicationLoad) {
                maxCommunicationLoad = commCount;
            }
        }

        double avgCommunication = static_cast<double>(totalCommunications) / numPartitions;

        // Determine if this file has minimum communication
        if (totalCommunications < minTotalCommunications ||
            (totalCommunications == minTotalCommunications && avgCommunication < minAvgCommunication) ||
            (totalCommunications == minTotalCommunications && avgCommunication == minAvgCommunication && maxCommunicationLoad < minMaxCommunicationLoad)) {
            minTotalCommunications = totalCommunications;
            minAvgCommunication = avgCommunication;
            minMaxCommunicationLoad = maxCommunicationLoad;
            bestFileIndex = static_cast<int>(i);
        }

        std::cout << std::endl;
    }

    if (bestFileIndex >= 0) {
        std::cout << "The file with the minimum communication is: " << vtkFiles[bestFileIndex] << std::endl;
    } else {
        std::cout << "No valid VTK files were processed." << std::endl;
    }
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <path_to_vtk_file_1> [<path_to_vtk_file_2> ...]" << std::endl;
        return EXIT_FAILURE;
    }

    std::vector<std::string> vtkFiles;
    for (int i = 1; i < argc; ++i) {
        vtkFiles.push_back(argv[i]);
    }

    // Compare communication results for the provided VTK files
    compareCommunicationResults(vtkFiles);

    return EXIT_SUCCESS;
}

