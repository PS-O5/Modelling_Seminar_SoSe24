#include <iostream>
#include <vector>
#include <cmath>



const double TOLERANCE = 1e-10;  // Convergence tolerance

// Function to perform matrix-vector multiplication
std::vector<double> matVecMultiply(const std::vector<std::vector<double>>& A, const std::vector<double>& x) {
    int n = A.size();
    std::vector<double> result(n, 0.0);
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            result[i] += A[i][j] * x[j];
        }
    }
    return result;
}

// Function to compute dot product of two vectors
double dotProduct(const std::vector<double>& v1, const std::vector<double>& v2) {
    double result = 0.0;
    for (size_t i = 0; i < v1.size(); ++i) {
        result += v1[i] * v2[i];
    }
    return result;
}

// Function to add two vectors with a scalar multiplier
std::vector<double> vecAdd(const std::vector<double>& v1, const std::vector<double>& v2, double scalar = 1.0) {
    int n = v1.size();
    std::vector<double> result(n, 0.0);
    for (int i = 0; i < n; ++i) {
        result[i] = v1[i] + scalar * v2[i];
    }
    return result;
}

// Conjugate Gradient Solver
std::vector<double> conjugateGradient(const std::vector<std::vector<double>>& A, const std::vector<double>& b, int maxIterations = 1000) {
    int n = b.size();
    std::vector<double> x(n, 0.0);  // Initial guess (x = 0)
    std::vector<double> r = b;  // Initial residual (r = b - Ax, with x=0)
    std::vector<double> p = r;  // Initial search direction
    double rsold = dotProduct(r, r);

    for (int i = 0; i < maxIterations; ++i) {
        std::vector<double> Ap = matVecMultiply(A, p);
        double alpha = rsold / dotProduct(p, Ap);
        
        if(std::isnan(alpha) || std::isinf(alpha)) {
            std::cerr << "Numerical instability detected: alpha is NaN or Inf." << std::endl;
            break;
        }
        
        x = vecAdd(x, p, alpha);  // Update the solution
        r = vecAdd(r, Ap, -alpha);  // Update the residual

        double rsnew = dotProduct(r, r);
        if (std::sqrt(rsnew) < TOLERANCE) {
            std::cout << "Converged in " << i + 1 << " iterations." << std::endl;
            break;
        }

        p = vecAdd(r, p, rsnew / rsold);  // Update the search direction
        rsold = rsnew;
    }

    return x;
}

void printVec(const std::vector<double>& A) {
        for (const auto& ele : A) {
            std::cout << ele << " ";
        }
        std::cout << std::endl;
}

void printMat(const std::vector<std::vector<double>>& A) {
    for (const auto& row : A) {
        for (const auto& ele : row) {
            std::cout << ele << " ";
        }
        std::cout << std::endl;
    }
}

void setBC(std::vector<double>& b, int h) {
    int grid = h * h;

    for (int i = 0; i < grid; ++i) {
        int row = i / h;  // Determine the row index
        int col = i % h;  // Determine the column index

        // Check if the element is on the boundary
        if (row == 0 || row == h - 1 || col == 0 || col == h - 1) {
            b[i] = 0.0;  // Boundary elements set to 0
        } else {
            b[i] = 1.0;  // Interior elements set to 1
        }
    }
}

std::vector<std::vector<double>> fillMatX(const int& h) {
    std::vector<std::vector<double>> result(h, std::vector<double>(h, 0.0));
    double d = 1.0 / (h - 1);
    for (int i = 0; i < h; i++) {
        for (int j = 0; j < h; j++) {
            result[i][j] = d * j;
        }
    }
    return result;
}

std::vector<std::vector<double>> fillMatY(const int& h) {
    std::vector<std::vector<double>> result(h, std::vector<double>(h, 0.0));
    double d = 1.0 / (h - 1);
    for (int i = 0; i < h; i++) {
        for (int j = 0; j < h; j++) {
            result[j][i] = d * j;
        }
    }
    return result;
}

std::vector<std::vector<double>> stiffMat(const int&h){
	int grid = h * h;
	std::cout << "grid size: " << grid << std::endl;
	std::vector<std::vector<double>> result(grid, std::vector<double>(grid, 0.0));

		
    for (int i = 0; i < grid; i++) {  // Iterate over all grid points
        if (i >= h && i < grid - h) {  // Skip the first and last rows
            if (i % h != 0) {  // Skip the first column
                result[i][i - 1] = -1;  // Left neighbor
            }
            if ((i + 1) % h != 0) {  // Skip the last column
                result[i][i + 1] = -1;  // Right neighbor
            }
            result[i][i - h] = -1;  // Bottom neighbor
            result[i][i + h] = -1;  // Top neighbor
        }
        result[i][i] = 4;  // Diagonal element
    }	


	    
	for (int i = 0; i < grid; ++i) {
    		int row = i / h;  // Determine the row index
    		int col = i % h;  // Determine the column index

    		// Check if the element is on the boundary
    		if (row == 0 || row == h - 1 || col == 0 || col == h - 1) {
        		result[i][i] = 1.0;  // Set the diagonal element to 1 for Dirichlet BC
    		}
	}
    
   

    return result;

}

std::vector<std::vector<double>> anaSol(const std::vector<std::vector<double>>& X, const std::vector<std::vector<double>>& Y, const int& h) {
    std::vector<std::vector<double>> result(h, std::vector<double>(h, 0.0));
    int maxIterations = 7;

    for (int i = 1; i < h - 1; i++) {  // Exclude boundaries
        for (int j = 1; j < h - 1; j++) {
            double sum = 0.0;  // Reset sum for each (i, j) point

            // Calculate the series part
            for (int k = 1; k <= maxIterations; k += 2) {  // k odd
                double kpi = k * M_PI;
                double term = std::sin(kpi * (1 + X[i][j]) / 2.0) / (std::pow(k, 3) * std::sinh(kpi));
                term *= (std::sinh(kpi * (1 + Y[i][j]) / 2.0) + std::sinh(kpi * (1 - Y[i][j]) / 2.0));
                sum += term;
            }

            // Calculate the entire equation
            result[i][j] = ((1 - std::pow(X[i][j], 2)) / 2.0) - (16 / std::pow(M_PI, 3)) * sum;
        }
    }

    // Apply Dirichlet boundary conditions
    for (int i = 0; i < h; ++i) {
        result[i][0] = 0.0;           // Bottom boundary (y = 0)
        result[i][h-1] = 0.0;         // Top boundary (y = 1)
        result[0][i] = 0.0;           // Left boundary (x = 0)
        result[h-1][i] = 0.0;         // Right boundary (x = 1)
    }

    return result;
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <integer value for h>" << std::endl;
        return EXIT_FAILURE;
    }

    int h = std::atoi(argv[1]);
    h = h + 1;

    std::vector<std::vector<double>> X = fillMatX(h);
    printMat(X);

    std::vector<std::vector<double>> Y = fillMatY(h);
    printMat(Y);

    std::vector<std::vector<double>> R = anaSol(X, Y, h);
    std::cout << "ASolution:" << std::endl;
    printMat(R);

    std::vector<std::vector<double>> A = stiffMat(h);
    std::cout << "Stiff:" << std::endl;
    printMat(A);
    std::vector<double> b(h*h, 1.0);
    setBC(b,h);

    std::vector<double> Solution = conjugateGradient(A, b);
    std::cout << "NSolution" << std::endl;
    printVec(Solution);


    return EXIT_SUCCESS;
}

