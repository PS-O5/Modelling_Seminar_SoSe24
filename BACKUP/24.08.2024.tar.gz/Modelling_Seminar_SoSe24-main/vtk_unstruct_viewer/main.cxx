#include <vtkSmartPointer.h>
#include <vtkRenderer.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkDataSetReader.h>
#include <vtkDataSetMapper.h>
#include <vtkActor.h>
#include <vtkLookupTable.h>
#include <vtkProperty.h>
#include <vtkScalarBarActor.h>
#include <vtkTextProperty.h>
#include <vtkCellData.h>
#include <vtkPolyData.h>
#include <vtkNamedColors.h>
#include <vtkInteractorStyleTrackballCamera.h> // Include for trackball interaction

#include <iostream>

int main(int argc, char *argv[]) {
    // Check if the file path is provided as an argument
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <Filename.vtk>" << std::endl;
        return EXIT_FAILURE;
    }

    std::string vtkFilePath = argv[1];

    // Create a reader for the .vtk file
    vtkSmartPointer<vtkDataSetReader> reader = vtkSmartPointer<vtkDataSetReader>::New();
    reader->SetFileName(vtkFilePath.c_str());
    reader->Update();

    // Check if the file was read successfully
    vtkSmartPointer<vtkDataSet> dataset = reader->GetOutput();
    if (!dataset) {
        std::cerr << "Error reading the file: " << vtkFilePath << std::endl;
        return EXIT_FAILURE;
    }

    // Check if the "PartitionID" data is present in the cell data
    if (!dataset->GetCellData()->HasArray("PartitionID")) {
        std::cerr << "The selected VTK file does not contain a 'PartitionID' field." << std::endl;
        return EXIT_FAILURE;
    }

    // Extract the partition IDs
    vtkSmartPointer<vtkDataArray> partitionIDs = dataset->GetCellData()->GetArray("PartitionID");

    // Create a lookup table to map the partition IDs to colors
    vtkSmartPointer<vtkLookupTable> lookupTable = vtkSmartPointer<vtkLookupTable>::New();
    lookupTable->SetNumberOfTableValues(partitionIDs->GetNumberOfTuples());
    lookupTable->Build();

    // Create a mapper and set the scalar visibility based on the partition IDs
    vtkSmartPointer<vtkDataSetMapper> mapper = vtkSmartPointer<vtkDataSetMapper>::New();
    mapper->SetInputData(dataset);
    mapper->SetLookupTable(lookupTable);
    mapper->SetScalarModeToUseCellFieldData();
    mapper->SelectColorArray("PartitionID");
    mapper->SetScalarRange(partitionIDs->GetRange());

    // Create an actor to represent the data in the scene
    vtkSmartPointer<vtkActor> actor = vtkSmartPointer<vtkActor>::New();
    actor->SetMapper(mapper);
    actor->GetProperty()->SetOpacity(0.5);  // Set opacity to 50% for translucency

    // Create a renderer to render the scene
    vtkSmartPointer<vtkRenderer> renderer = vtkSmartPointer<vtkRenderer>::New();
    renderer->AddActor(actor);
    renderer->SetBackground(0.1, 0.2, 0.3);  // Background color

    // Create a render window to display the scene
    vtkSmartPointer<vtkRenderWindow> renderWindow = vtkSmartPointer<vtkRenderWindow>::New();
    renderWindow->AddRenderer(renderer);
    renderWindow->SetSize(800, 600);

    // Create a render window interactor to handle user input
    vtkSmartPointer<vtkRenderWindowInteractor> renderWindowInteractor = vtkSmartPointer<vtkRenderWindowInteractor>::New();
    renderWindowInteractor->SetRenderWindow(renderWindow);

    // Use trackball interaction style for better object manipulation
    vtkSmartPointer<vtkInteractorStyleTrackballCamera> style = vtkSmartPointer<vtkInteractorStyleTrackballCamera>::New();
    renderWindowInteractor->SetInteractorStyle(style);

    // Add a scalar bar to display the partition IDs
    vtkSmartPointer<vtkScalarBarActor> scalarBar = vtkSmartPointer<vtkScalarBarActor>::New();
    scalarBar->SetLookupTable(lookupTable);
    scalarBar->SetTitle("Partition ID");
    scalarBar->GetLabelTextProperty()->SetColor(1.0, 1.0, 1.0);  // Set text color to white
    renderer->AddActor2D(scalarBar);

    // Start the rendering loop
    renderWindow->Render();
    renderWindowInteractor->Start();

    return EXIT_SUCCESS;
}

