import vtk
from vtk.util import numpy_support
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from tkinter import Tk
from tkinter.filedialog import askopenfilename

# Function to load VTK file
def load_vtk_file(file_path):
    reader = vtk.vtkUnstructuredGridReader()
    reader.SetFileName(file_path)
    reader.Update()
    return reader.GetOutput()

# Function to visualize VTK data with element numbering
def visualize_vtk_data(vtk_data):
    # Convert VTK points to numpy array
    points = numpy_support.vtk_to_numpy(vtk_data.GetPoints().GetData())

    # Create a matplotlib figure
    fig = plt.figure()
    
    # Determine dimensionality of the mesh
    dim = points.shape[1]
    
    if dim == 1:
        ax = fig.add_subplot(111)
    elif dim == 2:
        ax = fig.add_subplot(111)
    else:
        ax = fig.add_subplot(111, projection='3d')

    # Convert VTK cells to numpy array
    cell_types = vtk_data.GetCellTypesArray()

    # Color map to differentiate elements
    cmap = plt.get_cmap('tab20')

    # Iterate over each cell and plot it with a different color and number
    for i in range(vtk_data.GetNumberOfCells()):
        cell_type = cell_types.GetValue(i)
        cell = vtk_data.GetCell(i)
        cell_point_ids = cell.GetPointIds()

        # Extract the cell points
        cell_points = np.array([points[cell_point_ids.GetId(j)] for j in range(cell.GetNumberOfPoints())])

        if dim == 1:
            # Plot for 1D mesh
            ax.plot(cell_points[:, 0], np.zeros_like(cell_points[:, 0]), 'o-', color=cmap(i % 20))
            centroid = np.mean(cell_points[:, 0])
            ax.text(centroid, 0, str(i), color='black', fontsize=10, ha='center', va='center')
        elif dim == 2:
            # Plot for 2D mesh
            ax.fill(cell_points[:, 0], cell_points[:, 1], color=cmap(i % 20), alpha=0.5)
            centroid = np.mean(cell_points, axis=0)
            ax.text(centroid[0], centroid[1], str(i), color='black', fontsize=10, ha='center', va='center')
        else:
            unique_points = np.unique(cell_points[:, :2], axis=0)
            if len(unique_points) >= 3:
                # Plot for 3D mesh if the cell has 3 or more unique points in x and y
                ax.plot_trisurf(cell_points[:, 0], cell_points[:, 1], cell_points[:, 2], color=cmap(i % 20), alpha=0.5)
            elif len(unique_points) == 2:
                # If the cell has 2 unique points, plot a line
                ax.plot(cell_points[:, 0], cell_points[:, 1], cell_points[:, 2], 'o-', color=cmap(i % 20))
            elif len(unique_points) == 1:
                # If the cell has 1 unique point, plot a single point
                ax.scatter(cell_points[:, 0], cell_points[:, 1], cell_points[:, 2], color=cmap(i % 20))

            # Calculate and display the centroid for the hexahedron or other cells
            centroid = np.mean(cell_points, axis=0)
            ax.text(centroid[0], centroid[1], centroid[2], str(i), color='black', fontsize=10, ha='center', va='center')

    # Set plot labels and remove axes
    if dim == 1:
        ax.set_xlabel('X')
        ax.set_yticks([])
    elif dim == 2:
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
    else:
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('Z')

    ax.set_xticks([])
    ax.set_yticks([])
    if dim == 3:
        ax.set_zticks([])

    # Remove axes and grid
    ax.axis('off')
    
    plt.show()

# Main function to load and visualize VTK file
def main():
    # Use Tkinter to open a file dialog
    Tk().withdraw()  # Close the root window
    file_path = askopenfilename(filetypes=[("VTK files", "*.vtk")])
    
    if not file_path:
        print("No file selected.")
        return
    
    # Load VTK data
    vtk_data = load_vtk_file(file_path)
    
    # Visualize the data
    visualize_vtk_data(vtk_data)

if __name__ == '__main__':
    main()

