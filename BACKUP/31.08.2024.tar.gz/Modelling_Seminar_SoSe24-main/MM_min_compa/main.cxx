#include <gtk/gtk.h>
#include <vtkSmartPointer.h>
#include <vtkUnstructuredGrid.h>
#include <vtkUnstructuredGridReader.h>
#include <vtkCellData.h>
#include <vtkPointData.h>
#include <vtkDataSet.h>
#include <vtkIntArray.h>
#include <vtkCell.h>
#include <vtkPoints.h>
#include <vtkIdList.h>
#include <vtkFieldData.h>

#include <iostream>
#include <map>
#include <set>
#include <string>
#include <vector>
#include <numeric>

// Function to parse and analyze communication between partitions
std::map<int, std::set<int>> analyzePartitionCommunication(vtkUnstructuredGrid* unstructuredGrid) {
    vtkCellData* cellData = unstructuredGrid->GetCellData();
    
    std::map<int, std::set<int>> communicationMap;

    if (!cellData) {
        std::cerr << "No cell data found in the VTK file." << std::endl;
        return communicationMap;
    }

    // Assuming partition information is stored as an integer array in cell data
    vtkIntArray* partitionArray = vtkIntArray::SafeDownCast(cellData->GetArray("PartitionID"));
    
    if (!partitionArray) {
        std::cerr << "No PartitionID data found in the VTK file." << std::endl;
        return communicationMap;
    }

    // Iterate through all the cells in the unstructured grid
    for (vtkIdType i = 0; i < unstructuredGrid->GetNumberOfCells(); ++i) {
        vtkCell* cell = unstructuredGrid->GetCell(i);
        int partitionId = partitionArray->GetValue(i);

        // Iterate through the cell's points to find neighboring cells
        vtkIdList* pointIds = cell->GetPointIds();
        for (vtkIdType j = 0; j < pointIds->GetNumberOfIds(); ++j) {
            vtkIdType pointId = pointIds->GetId(j);

            vtkSmartPointer<vtkIdList> neighboringCells = vtkSmartPointer<vtkIdList>::New();
            unstructuredGrid->GetPointCells(pointId, neighboringCells);

            for (vtkIdType k = 0; k < neighboringCells->GetNumberOfIds(); ++k) {
                vtkIdType neighborCellId = neighboringCells->GetId(k);
                int neighborPartitionId = partitionArray->GetValue(neighborCellId);

                // If the neighboring cell belongs to a different partition, record communication
                if (neighborPartitionId != partitionId) {
                    communicationMap[partitionId].insert(neighborPartitionId);
                }
            }
        }
    }

    return communicationMap;
}

// Function to analyze and print communication metrics
void printCommunicationMetrics(const std::map<int, std::set<int>>& communicationMap) {
    int totalCommunications = 0;
    int maxCommunicationLoad = 0;
    int numPartitions = communicationMap.size();

    for (const auto& entry : communicationMap) {
        int commCount = entry.second.size();
        totalCommunications += commCount;
        if (commCount > maxCommunicationLoad) {
            maxCommunicationLoad = commCount;
        }
    }

    double avgCommunication = static_cast<double>(totalCommunications) / numPartitions;

    std::cout << "Total communications: " << totalCommunications << std::endl;
    std::cout << "Average communications per partition: " << avgCommunication << std::endl;
    std::cout << "Maximum communication load (max number of communications a partition has): " << maxCommunicationLoad << std::endl;
}

// Function to compare communication results between multiple VTK files
void compareCommunicationResults(const std::vector<std::string>& vtkFiles) {
    int bestFileIndex = -1;
    int minTotalCommunications = std::numeric_limits<int>::max();
    double minAvgCommunication = std::numeric_limits<double>::max();
    int minMaxCommunicationLoad = std::numeric_limits<int>::max();

    for (size_t i = 0; i < vtkFiles.size(); ++i) {
        std::cout << "Analyzing file: " << vtkFiles[i] << std::endl;

        // Read the .vtk file
        vtkSmartPointer<vtkUnstructuredGridReader> reader = vtkSmartPointer<vtkUnstructuredGridReader>::New();
        reader->SetFileName(vtkFiles[i].c_str());
        reader->Update();

        vtkUnstructuredGrid* unstructuredGrid = reader->GetOutput();
        if (!unstructuredGrid) {
            std::cerr << "Failed to read the VTK file: " << vtkFiles[i] << std::endl;
            continue;
        }

        // Analyze partition communication
        std::map<int, std::set<int>> communicationMap = analyzePartitionCommunication(unstructuredGrid);

        // Print communication metrics
        std::cout << "Partition Communication Analysis for file: " << vtkFiles[i] << std::endl;
        printCommunicationMetrics(communicationMap);

        // Calculate metrics for comparison
        int totalCommunications = 0;
        int maxCommunicationLoad = 0;
        int numPartitions = communicationMap.size();

        for (const auto& entry : communicationMap) {
            int commCount = entry.second.size();
            totalCommunications += commCount;
            if (commCount > maxCommunicationLoad) {
                maxCommunicationLoad = commCount;
            }
        }

        double avgCommunication = static_cast<double>(totalCommunications) / numPartitions;

        // Determine if this file has minimum communication
        if (totalCommunications < minTotalCommunications ||
            (totalCommunications == minTotalCommunications && avgCommunication < minAvgCommunication) ||
            (totalCommunications == minTotalCommunications && avgCommunication == minAvgCommunication && maxCommunicationLoad < minMaxCommunicationLoad)) {
            minTotalCommunications = totalCommunications;
            minAvgCommunication = avgCommunication;
            minMaxCommunicationLoad = maxCommunicationLoad;
            bestFileIndex = static_cast<int>(i);
        }

        std::cout << std::endl;
    }

    if (bestFileIndex >= 0) {
        std::cout << "****The file with the minimum communication is: " << vtkFiles[bestFileIndex] << std::endl;
    } else {
        std::cout << "No valid VTK files were processed." << std::endl;
    }
}

// Callback function for the GTK button
static void on_file_open(GtkWidget *widget, gpointer data) {
    GtkWidget *dialog;
    dialog = gtk_file_chooser_dialog_new("Open File",
                                         GTK_WINDOW(data),
                                         GTK_FILE_CHOOSER_ACTION_OPEN,
                                         "_Cancel",
                                         GTK_RESPONSE_CANCEL,
                                         "_Open",
                                         GTK_RESPONSE_ACCEPT,
                                         NULL);
    gtk_file_chooser_set_select_multiple(GTK_FILE_CHOOSER(dialog), TRUE);

    if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_ACCEPT) {
        GSList *filenames = gtk_file_chooser_get_filenames(GTK_FILE_CHOOSER(dialog));
        std::vector<std::string> vtkFiles;

        for (GSList *iter = filenames; iter != NULL; iter = iter->next) {
            vtkFiles.push_back(static_cast<char *>(iter->data));
            g_free(iter->data); // Free each filename string after use
        }

        g_slist_free(filenames); // Free the GSList structure

        compareCommunicationResults(vtkFiles);
    }

    gtk_widget_destroy(dialog);
}

int main(int argc, char* argv[]) {
    gtk_init(&argc, &argv);

    GtkWidget *window;
    GtkWidget *button;
    GtkWidget *box;

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "VTK Partition Analysis");
    gtk_window_set_default_size(GTK_WINDOW(window), 200, 100);
    gtk_container_set_border_width(GTK_CONTAINER(window), 10);

    box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_container_add(GTK_CONTAINER(window), box);

    button = gtk_button_new_with_label("Select VTK Files");
    g_signal_connect(button, "clicked", G_CALLBACK(on_file_open), window);
    gtk_box_pack_start(GTK_BOX(box), button, TRUE, TRUE, 0);

    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    gtk_widget_show_all(window);
    gtk_main();

    return 0;
}

