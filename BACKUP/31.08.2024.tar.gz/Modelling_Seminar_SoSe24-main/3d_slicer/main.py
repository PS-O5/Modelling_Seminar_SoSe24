import pyvista as pv
import numpy as np
import tkinter as tk
from tkinter import filedialog

def read_vtk(filename):
    # Load the VTK file using pyvista
    mesh = pv.read(filename)
    return mesh

def visualize_slice(mesh, z_value, opacity=1.0):
    # Slice the mesh at a given Z value
    sliced_mesh = mesh.slice_orthogonal(z=z_value)
    
    # Plot the sliced mesh with partition coloring if available
    plotter = pv.Plotter()
    if 'PartitionID' in mesh.cell_data:
        plotter.add_mesh(sliced_mesh, scalars='PartitionID', show_edges=True, cmap='viridis', opacity=opacity)
        plotter.add_scalar_bar(title='PartitionID')
    else:
        plotter.add_mesh(sliced_mesh, opacity=opacity)
    plotter.show()

def get_z_slices(mesh, num_slices):
    bounds = mesh.bounds
    z_min, z_max = bounds[4], bounds[5]
    z_values = np.linspace(z_min, z_max, num_slices)
    return z_values

def select_file():
    # Create a Tkinter file selection dialog
    root = tk.Tk()
    root.withdraw()
    file_path = filedialog.askopenfilename(filetypes=[("VTK files", "*.vtk")])
    return file_path

def main():
    # Select a file
    vtk_file = select_file()
    if not vtk_file:
        print("No file selected.")
        return
    
    # Read the VTK file
    mesh = read_vtk(vtk_file)
    
    # Ask the user for the number of slices
    num_slices = int(input("Enter the number of slices along the Z-axis: "))
    
    # Get the Z slice values
    z_slices = get_z_slices(mesh, num_slices)
    
    # Visualize each slice
    for z in z_slices:
        print(f"Displaying slice at Z = {z}")
        visualize_slice(mesh, z, opacity=0.6)

if __name__ == "__main__":
    main()

